# Safe Sightings of Signs and Signals (SSOSS or SOS)

SOS is an automated tool to check visibility to static road objects such as signs and traffic signals. It is based on predefined sight distances. This tool provides
a repeatable way to monitor and verify signs and traffic signals are visible along any roadway that GPS data and video are recorded on.

This project is a collection of Python classes, methods, and notebooks that are simple and free to use.

## Features
Video Synchronization Helper Tools: Python functions are provided to export the video frames and help to synchronize the video file.
Automated data processing: The SOS program uses a combination of GPS and video data to extract images of traffic signals and/or roadway signs.
Image Labeling and animated GIF image tools: Python functions are included to label images or create an animated GIF from multiple images 
## Requirements
Python 3.8
Required libraries: pandas, numpy, opencv-python, geopy, gpxpy, imageio, tqdm, lxml 
## Installation
To install the SOS program, follow these steps:

    python3 -m pip install ssoss

## Usage
To use the SOS program, 
1. Setup the necessary input files in A and B. 
2. Follow the data processing commands in Part C. Jupyter Notebook available as example

### A. Input Files
Data related to the static road objects (signs and traffic signals) need to be saved in a CSV file for used in processing.
The intersection CSV file has the following format (as a minimum)

ID, Streetname 1, Streetname 2, Center_Latitude, Center_Longitude, Posted Speed (MPH) of NB Approach, Posted Speed (MPH) of EB Approach, 
Posted Speed (MPH) of SB Approach, Posted Speed (MPH) of WB Approach, NB Approach Compass Heading, EB Approach Compass Heading,
SB Approach Compass Heading, WB Approach Compass Heading

### B. Data Collection
Collect data simultaneously:
1. GPX recording
   a. Use GPX Version 1.0 with logging every second
2. Video Recording
   a. Record at 5 Megapixel resolution or more
   b. Record at 30 frames per second or higher

### C. Data Processing
See example notebooks (coming soon)
#### File Setup
Save Signal .CSV to:
./in/

Save GPX and Video files to:
./in/gpx_video/

#### Example Usage
        import ssoss as ss

        signals = "signal.csv"
        gpx = "drive.gpx"

        signal_project = ss.ProcessRoadObjects(signals, gpx)
        sightings = signal_project.intersection_checks()

        vid_file = "drive_1.MP4"
        video = ss.ProcessVideo(vid_file)
        video.sync(200, "2022-09-08T14:21:54.988Z")  #  See Sync Process below
        video.extract_images(sightings)

From there, progress bars will be displayed while the images are saved to the output folder.

#### Sync GPX & Video Process
Synchronizing the GPX file and the video could be one of the largest sources of error. The ProcessVideo Class has
a helper function to perform a acurate syncronization time. The extract_frames_between method can export all the 
video frames between two time vales. When looking at the GPX points, the approximate video time can be estimated 
and all the frames can be extracted. This method is:

        video.extract_frames_between(start_sec=20, end_sec=40)

Check the printed logs to see the saved output location. Default is:
./out/frames/[video filename]/###.jpg
where ### is the frame number of the image.

Use the frame number and the GPX recorded time to line up the best point to syncronize the video using the Sync method.

        video.sync(frame = 200, timestamp="2022-09-08T14:21:54.988Z")

## Documentation
### Jupter Notebook Examples
coming soon
### Helper Functions
    GIF creator
### Heuristic

For Each GPX Point:
* What are the closest & approaching intersections
  * Based on compass heading of moving vehicle and input data (.csv), which approach leg is vehicle on?
    * What is the approach speed of that approach leg, and look up sight distance for that speed
      * Is the current GPX point greater than that sight distance and the next point is less than the sight distance,
        * If yes, then calculate acceleration between those two points and estimate the time the vehicle 
        traveled over the sight distance.
        * If no, go to next GPX point

From the sight distance timestamp and synchronized video file, the frame is extracted that is closest to that time.

## Contributions
Contributions are welcome to the SSOSS project! If you have an idea for a new feature or have found a bug, please open an issue or submit a pull request.

## License
The SSOSS project is licensed under the MIT License. See LICENSE for more information.